$(document).ready(function(){
	var mySlider = $('.main-visual-list').bxSlider({
		auto:true,
		controls:false
	});
});